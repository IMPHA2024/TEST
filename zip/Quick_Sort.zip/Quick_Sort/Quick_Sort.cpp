#include <iostream>
#include<time.h>
#include <chrono>

using namespace std;

typedef struct arr_node
{
	int data;
	arr_node* next;
	arr_node() :data(0), next(nullptr) {};
}arr_node;

class arr
{
public:
	arr():head(nullptr) {};
	~arr()
	{
		arr_node* temp = head;
		if (temp == nullptr) return;
		while (temp->next != nullptr)
		{
			arr_node* temp1 = temp;
			temp = temp->next;
			delete temp1;
		}
		delete temp;
	};
	void out()
	{
		arr_node* temp = head;
		if (temp == nullptr) return;
		while (temp->next != nullptr)
		{
			cout << temp->data << " ";
			temp = temp->next;
		}
		cout << temp->data;
		cout << endl;
	}
	void set()
	{
		int in;
		cout << "输入任意字母结束关键词输入" << endl;
		while (cin >> in)
		{
			arr_node* fresh = new arr_node();
			fresh->data = in;
			if (head == nullptr)
			{
				head = fresh;
			}
			else
			{
				arr_node* temp = head;
				while (temp->next != nullptr) temp = temp->next;
				temp->next = fresh;
			}
		}
		cin.clear(); // 清除错误状态
		cin.ignore(numeric_limits<streamsize>::max(), '\n'); // 忽略到换行符
	}
	int size() const
	{
		int ans = 1;
		arr_node* temp = head;
		if (temp == nullptr) return 0;
		while (temp->next != nullptr)
		{
			temp = temp->next;
			ans++;
		}
		return ans;
	};
	int find(int index)
	{
		arr_node* temp = head;
		for (int i = 0;i < index;i++)
		{
			temp = temp->next;
		}
		return temp->data;
	}
	void change(int index,int in)
	{
		arr_node* temp = head;
		for (int i = 0;i < index;i++)
		{
			temp = temp->next;
		}
		temp->data = in;
	}
	void operator = (const arr & a)
	{
		arr_node* last = nullptr;
		arr_node* temp1 = a.head;
		for (int i = 0;i < a.size();i++)
		{
			arr_node* fresh = new arr_node();
			fresh->data = temp1->data;
			fresh->next = nullptr;
			if (head == nullptr) {head = fresh;last = head;}
			else
			{
				last->next = fresh;
				last = last->next;
			}
			temp1 = temp1->next;
		}
	};
private:
	arr_node* head;
};

void Quick_Sort1(arr & in,int left,int right)//int left = 0, right = in.size(); hoare
{
	if (left >= right) return;//结束分治
	else
	{
		int l_i = left, r_i = right;//l_i和r_i初始化为待排序数组的两侧
		int mid = (left + right) / 2;//pivot索引
		int temp = in.find(mid);//pivot取中值
		while (l_i <= r_i)//结束条件为l_i与r_i相遇
		{
			while (in.find(l_i) < temp ) l_i++;//l_i遇到大于等于pivot终止
			while (in.find(r_i) > temp ) r_i--;//r_i遇到小于等于pivot终止
			if (l_i <= r_i)//防止l_i与r_i越界
			{
				int cha = in.find(l_i);//swap(&in.find(r_i),in.find(l_i))
				in.change(l_i, in.find(r_i));
				in.change(r_i, cha);
				l_i++;
				r_i--;
			}
		}
		Quick_Sort1(in, left, r_i);
		Quick_Sort1(in, l_i, right);
	}
};

void Quick_Sort2(arr& in, int left, int right)
{
	if (left >= right) return;
	int pivot = in.find(left);
	int l_i = left,r_i = right,temp;
	while (l_i!= r_i)
	{
		while (in.find(r_i) >= pivot&&l_i<r_i) r_i--;
		temp = in.find(r_i);
		in.change(l_i, temp);
		while (in.find(l_i) < pivot&& l_i <r_i) l_i++;
		temp = in.find(l_i);
		in.change(r_i, temp);
	}
	in.change(r_i, pivot);
	Quick_Sort2(in, left, l_i - 1);
	Quick_Sort2(in, l_i + 1,right);
};

void test()
{
	arr a,b;
	a.set();
	b = a;
	auto start = std::chrono::high_resolution_clock::now();
	Quick_Sort1(a, 0, a.size()-1);
	auto end = std::chrono::high_resolution_clock::now();
	std::chrono::duration<double, std::milli> duration = end - start;

	auto start1 = std::chrono::high_resolution_clock::now();
	Quick_Sort2(b, 0, b.size()-1);
	auto end1 = std::chrono::high_resolution_clock::now();
	std::chrono::duration<double, std::milli> duration1 = end1 - start1;
	a.out();
	cout << duration.count() << " ms" << endl;
	b.out();
	cout << duration1.count() << " ms" << endl;
}

int main()
{
	test();
}