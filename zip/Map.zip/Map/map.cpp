#include <algorithm>
#include <iostream>
#include <queue>
using namespace std;

typedef struct line
{
	int i, j;
	double weight;
	line() :i(0), j(0), weight(0) {};
}line;
bool cmp(line a,line b)
{
	return a.weight < b.weight;
}

//1
class AdMatrix//�ڽӾ���(����,����)
{
public:
	AdMatrix():data(nullptr), node_num(0),line_num(0),cap_flag(0) {};
	~AdMatrix()
	{
		for (int i = 0;i < node_num;i++)
		{
			delete[] data[i];
		}
		delete[] data;
	};
	int Set_Matrix()
	{
		int n=0,m=0;
		char a = '\0', b = '\0';
		int ii = 0;
		cout << "��Ȩֵ��0������Ȩֵ��1��" << endl;
		cin >> ii;
		cout << "����ڵ����" << endl;
		cin >> n;
		node_num = n;
		data = new double* [n];
		for (int i = 0;i < n;i++) data[i] = new double[n];
		for (int i = 0;i < n;i++)//-1�������ڵ��ʼ��������
		{
			for (int j = 0;j < n;j++) data[i][j] = -1;
		}
		for (int i = 0;i < n;i++) data[i][i] = 0;//0�����ڵ�������
		cout << "����߸���" << endl;
		cin >> m;
		line_num = m;
		if (ii == 0)
		{
			cout << "����� �磨AB��" << endl;
			for (int i = 0;i < m;i++)
			{
				cin >> a >> b;
				if (a >= 'a')
				{
					a -= 32;
					cap_flag = 1;
				}
				if (b >= 'a') b -= 32;
				if ((int)a - 65 < 0 || (int)b - 65 < 0 || (int)b - 65 >= n || (int)a - 65 >= n) return(-1);
				if (data[(int)a - 65][(int)b - 65] == -1) data[(int)a - 65][(int)b - 65] = 1;
				else data[(int)a - 65][(int)b - 65]++;
			}
		}
		else if (ii == 1)
		{
			cout << "����� �磨AB��" << endl;
			for (int i = 0;i < m;i++)
			{
				double weight = 0;
				cin >> a >> b;
				cout << "����ߵ�Ȩֵ" << endl;
				cin >> weight;
				if (a >= 'a')
				{
					a -= 32;
					cap_flag = 1;
				}
				if (b >= 'a') b -= 32;
				if ((int)a - 65 < 0 || (int)b - 65 < 0 || (int)b - 65 >= n || (int)a - 65 >= n) return(-1);
				if (data[(int)a - 65][(int)b - 65] == -1) data[(int)a - 65][(int)b - 65] = weight;
				else data[(int)a - 65][(int)b - 65]++;
			}
		}
		return 0;
	};
	int Print_Matrix()
	{
		char a = 'A';
		if (cap_flag == 1) a = 'a';
		cout << "    ";
		for (int i = 0;i < node_num;i++)
		{
			cout << (char)(a + (int)i) << "   ";
		}
		cout << endl;
		for (int i = 0;i < node_num;i++)
		{
			cout << (char)(a + (int)i) << "   ";
			for (int j = 0;j < node_num;j++)
			{
				cout << data[i][j] << "  ";
			}
			cout << endl;
		}
		return 0;
	};
	void DFS(string& out,int index)
	{
		static int* trans=new int[node_num];
		if (cap_flag == 1)out.push_back('a' + index);
		else if (cap_flag == 0)out.push_back('A' + index);
		trans[index] = 1;
		int i = 0,flag=0;
		for (i;i < node_num;i++)
		{
			if (data[index][i] >= 1 && trans[i]!=1)
			{
				DFS(out, i);
			}
		}
	}
	void BFS(string& out, int index)
	{
		queue<int> q;
		int* trans = new int[node_num];
		for (int i = 0;i < node_num;i++)trans[i] = 0;
		q.push(index);
		trans[index] = 1;
		while (q.empty() != true)
		{
			index = q.front();
			if (cap_flag == 1)out.push_back('a' + index);
			else if (cap_flag == 0)out.push_back('A' + index);
			q.pop();
			for (int i = 0;i < node_num;i++)
			{
				if (data[index][i] >= 1 && trans[i] != 1)
				{
					q.push(i);
					trans[i] = 1;
				}
			}
		}
	}
	double Prim(string &out,int index)
	{
		double sum = 0;
		double* lowcost = new double[node_num];
		int* trans = new int[node_num];
		for (int i = 0;i < node_num;i++)
		{
			trans[i] = 0;
			lowcost[i] = -1;
		}
		for (int i = 0;i < node_num;i++)
		{
			lowcost[i] = data[index][i];
		}
		if (cap_flag == 0) out.push_back('A' + index);
		else out.push_back('a' + index);
		trans[index] = 1;
		for (int i = 0;i < node_num - 1;i++)
		{
			double min = DBL_MAX;
			for (int j = 0;j < node_num;j++)
			{
				if (trans[j] == 1) continue;
				if (lowcost[j] != -1 && min> lowcost[j])
				{
					min = lowcost[j];
					index = j;
				}
			}
			if (min != DBL_MAX)
			{
				sum += min;
				if (cap_flag == 0) out.push_back('A' + index);
				else out.push_back('a' + index);
				trans[index] = 1;
				for (int j = 0;j < node_num;j++)
				{
					if(lowcost[j]==-1)lowcost[j] = data[index][j];
					else if (data[index][j] < lowcost[j] && data[index][j]!=-1) lowcost[j] = data[index][j];
				}
			}
			else
			{
				if (i < node_num)
				{
					cout << "����ͨͼ" << endl;
					return -1;
				}
			}
		}
		return sum;
	}
	double Kruskal(string& out)
	{
		double sum = 0;
		int* trans = new int[node_num];
		int* visit = new int[node_num];
		line* lines = new line[line_num];
		for (int i = 0;i < node_num;i++)
		{
			trans[i] = i;
			visit[i] = 0;
			lines[i].weight = 0;
		}
		int index = 0;
		for (int i = 0;i < node_num;i++)
		{
			for (int j = 0;j < node_num;j++)
			{
				if (data[i][j] != -1 && data[i][j] != 0)
				{
					lines[index].weight = data[i][j];
					lines[index].i = i;
					lines[index].j = j;
					index++;
				}
			}
		}
		for (int i = 0;i < line_num;i++)
		{
			for (int j = 0;j <line_num - 1-i;j++)
			{
				if (lines[j].weight > lines[j + 1].weight)
				{
					line temp = lines[j];
					lines[j] = lines[j + 1];
					lines[j + 1] = temp;
				}
			}
		}
		for (int i = 0;i < node_num - 1;i++)
		{
			int num = i;
			while (find(trans, lines[num].i) == find(trans, lines[num].j)) num++;
			out.push_back('<');
			if (cap_flag == 0) { out.push_back('A' + lines[num].i); out.push_back('A' + lines[num].j);}
			else { out.push_back('a' + lines[num].i);out.push_back('a' + lines[num].j);}
			out.push_back('>');
			sum += lines[num].weight;
			trans[lines[num].j] = lines[num].i;
		}
		return sum;
	};
	int find(int* trans,int a)//FIND SET
	{
		if (trans[a] == a) return a;
		else
		{
			return find(trans, trans[a]);
		}
	}
	double Dijkstra(string& out, int index)
	{
		double sum = 0;
		double* lowcost = new double[node_num];
		int* trans = new int[node_num];
		for (int i = 0;i < node_num;i++)
		{
			trans[i] = 0;
			lowcost[i] = -1;
		}
		for (int i = 0;i < node_num;i++)
		{
			lowcost[i] = data[index][i];
		}
		if (cap_flag == 0) out.push_back('A' + index);
		else out.push_back('a' + index);
		trans[index] = 1;
		for (int i = 0;i < node_num - 1;i++)
		{
			double min = DBL_MAX;
			for (int j = 0;j < node_num;j++)
			{
				if (trans[j] == 1) continue;
				if (lowcost[j] != -1 && min > lowcost[j])
				{
					min = lowcost[j];
					index = j;
				}
			}
			if (min != DBL_MAX)
			{
				sum += min;
				if (cap_flag == 0) out.push_back('A' + index);
				else out.push_back('a' + index);
				trans[index] = 1;
				for (int j = 0;j < node_num;j++)
				{
					if (lowcost[j] == -1)lowcost[j] = data[index][j];
					else if (data[index][j]+lowcost[index] < lowcost[j] && data[index][j] != -1) lowcost[j] = data[index][j]+ lowcost[index];
				}
			}
			else
			{
				if (i < node_num-1)
				{
					cout << "����ͨͼ" << endl;
					break;
				}
			}
		}
		return sum;
	}
	void Floyd()
	{
		double** temp=new double*[node_num];
		for (int i = 0;i < node_num;i++)
		{
			temp[i] = new double[node_num];
		}
		for (int i = 0;i < node_num;i++)
		{
			for (int j = 0;j < node_num;j++) temp[i][j] = data[i][j];
		}
		for (int k = 1;k < node_num;k++)
		{
			for (int i = 0;i < node_num;i++)
			{
				for (int j = 0;j < node_num;j++)
				{
					if (temp[i][j] == -1 )
					{
						if (temp[i][k] != -1 && temp[k][j] != -1)
						{
							temp[i][j] = temp[i][k] + temp[k][j];
						}
					}
					else if (temp[i][j] > temp[i][k] + temp[k][j])
					{
						if (temp[i][k] != -1 && temp[k][j] != -1)
						{
							temp[i][j] = temp[i][k] + temp[k][j];
						}
					}
				}
			}
		}
		char a = 'A';
		if (cap_flag == 1) a = 'a';
		cout << "    ";
		for (int i = 0;i < node_num;i++)
		{
			cout << (char)(a + (int)i) << "   ";
		}
		cout << endl;
		for (int i = 0;i < node_num;i++)
		{
			cout << (char)(a + (int)i) << "   ";
			for (int j = 0;j < node_num;j++)
			{
				cout << temp[i][j] << "  ";
			}
			cout << endl;
		}
	}
private:
	double** data;
	int node_num;
	int line_num;
	int cap_flag;//Ĭ�ϴ�д=0
};
//2
typedef struct Adlist_Node
{
	char node;
	double weight;
	Adlist_Node* next;
	Adlist_Node() :node('\0'), next(nullptr),weight(0) {};
}Adlist_Node;
class Adlist_String
{
public:
	Adlist_String():HEAD(nullptr) {};
	~Adlist_String() 
	{
		Clear(HEAD);
	};
	void Clear(Adlist_Node* head)
	{
		if (head == nullptr);
		else
		{
			Clear(head->next);
			delete head;
		}
	};
	void Push(Adlist_Node* fresh)
	{
		Adlist_Node* temp = HEAD;
		if (HEAD == nullptr) HEAD = fresh;
		else
		{
			while (temp->next != nullptr) { temp = temp->next; }
			temp->next = fresh;
		}
		fresh->next = nullptr;
	};
	void Pop()
	{
		Adlist_Node* temp = HEAD;
		while (temp->next->next != nullptr) { temp = temp->next; }
		delete temp->next;
		temp->next = nullptr;
	};
	int Print(bool is_ori)
	{
		if (is_ori==1)
		{
			Adlist_Node* temp = HEAD;
			if (temp->next == nullptr)
			{
				cout<<temp->node << " -> ";
			}
			while (temp->next != nullptr)
			{
				cout << temp->node << " -> ";
				temp = temp->next;
			}
			if(temp!=HEAD)cout << temp->node << " -> ";
			cout << "#" << endl;
		}
		else
		{
			Adlist_Node* temp = HEAD;
			if (temp->next == nullptr)
			{
				cout << temp->node << " <-> ";
			}
			while (temp->next != nullptr)
			{
				cout << temp->node << " <-> ";
				temp = temp->next;
			}
			if(temp!=HEAD) cout << temp->node << " <-> ";
			cout << "#" << endl;
		}
		return 0;
	}
	Adlist_Node* HEAD;
};
class AdList
{
public:
	AdList() :data(nullptr),node_num(0),line_num(0),is_ori(false),caps(65) {};
	~AdList() 
	{
		delete[] data;
	};
	int Set_AdList()
	{
		bool ii = false;
		int oo = 0;
		cout << "��Ȩ��0����Ȩ��1��" << endl;
		cin >> oo;
		cout << "����0������1��" << endl;
		cin >> ii;
		is_ori = (bool)ii;
		int n = 0, m = 0;
		char a = '\0', b = '\0';
		int flag = 65;//Ĭ�ϴ�д
		cout << "����ڵ����" << endl;
		cin >> n;
		node_num = n;
		data = new Adlist_String[n];
		cout << "����߸���" << endl;
		cin >> m;
		line_num = m;
		cout << "����� �磨AB��" << endl;
		for (int i = 0;i < n;i++)
		{
			data[i].HEAD = new Adlist_Node();
			data[i].HEAD->node = 'A' + i;
		}
		switch (ii)
		{
		case true:
			for (int i = 0;i < m;i++)
			{
				cin >> a >> b;
				if (i == 0)
				{
					if (a >= 'a')
					{
						caps = 97;
						flag = 97;
						for (int i = 0;i < n;i++)
						{
							data[i].HEAD->node = 'a' + i;
						}
					}
				}
				Adlist_Node* fresh1 = new Adlist_Node();
				fresh1->node = b;
				if (oo == 1)
				{
					cout << "����Ȩֵ" << endl;
					cin >> fresh1->weight;
				}
				data[(int)a - flag].Push(fresh1);
			}
			break;
		case false:
			for (int i = 0;i < m;i++)
			{
				cin >> a >> b;
				if (i == 0)
				{
					if (a >= 'a')
					{
						caps = 97;
						flag = 97;
						for (int i = 0;i < n;i++)
						{
							data[i].HEAD->node = 'a' + i;
						}
					}
				}
				Adlist_Node* fresh1 = new Adlist_Node();
				fresh1->node = b;
				if (oo == 1)
				{
					cout << "����Ȩֵ" << endl;
					cin >> fresh1->weight;
				}
				data[(int)a - flag].Push(fresh1);
				Adlist_Node* fresh2 = new Adlist_Node();
				fresh2->node = a;
				fresh2->weight = fresh1->weight;
				data[(int)b - flag].Push(fresh2);
			}
			break;
		}
		return 0;
	};
	int Print_Adlist()
	{
		for (int i = 0;i < node_num;i++)
		{
			data[i].Print(is_ori);
		}
		return 0;  
	}
	void DFS(string& out, int index)
	{
		static int* trans = new int[node_num];
		trans[index] = 1;
		Adlist_Node* temp = data[index].HEAD;
		out.push_back(temp->node);
		if (temp->next == nullptr);
		else
		{
			while (temp->next != nullptr)
			{
				index = (int)temp->next->node - caps;
				if (trans[index] != 1)
				{
					DFS(out, index);
				}
				temp = temp->next;
			}
		}
	}
	void BFS(string& out, int index)
	{
		int* trans = new int[node_num];
		for (int i = 0;i < node_num;i++)trans[i] = 0;
		queue<char> q;
		Adlist_Node* temp = data[index].HEAD;
		q.push(temp->node);
		out.push_back(temp->node);
		trans[index] = 1;
		while (q.empty() != true)
		{
			temp = data[(int)q.front() - caps].HEAD->next;
			while (temp != nullptr)
			{
				if (trans[(int)temp->node - caps] != 1)
				{
					trans[(int)temp->node - caps] = 1;
					q.push(temp->node);
					out.push_back(temp->node);
				}
				temp = temp->next;
			}
			q.pop();
		}
	}
	double Prim(string& out ,int index)
	{
		double sum = 0;
		double* lowcost = new double[node_num];
		int* trans = new int[node_num];
		Adlist_Node* temp= data[index].HEAD;
		for (int i = 0;i < node_num;i++) lowcost[i] = trans[i] = 0;
		while (temp->next != nullptr)
		{
			temp = temp->next;
			lowcost[temp->node - caps] = temp->weight;
		}
		out.push_back(caps + index);
		trans[index] = 1;
		for (int i = 0;i < node_num - 1;i++)
		{
			double min = DBL_MAX;
			int min_index = 0;
			for (int j = 0;j < node_num;j++)
			{
				if (trans[j] == 1) continue;
				if (min > lowcost[j] && lowcost[j] != 0) {min = lowcost[j];min_index = j;}
			}
			if (min == DBL_MAX && i < node_num - 1)
			{
				cout << "����ͨͼ" << endl;
				return -1;
			}
			trans[min_index] = 1;
			sum += lowcost[min_index];
			out.push_back(caps + min_index);
			temp = data[min_index].HEAD;
			while (temp->next != nullptr)
			{
				temp = temp->next;
				if(lowcost[temp->node-caps]==0) lowcost[temp->node - caps] = temp->weight;
				else if(lowcost[temp->node - caps]>temp->weight)lowcost[temp->node - caps] = temp->weight;
			}
		}
		return sum;
	}
	double Kruskal(string& out)
	{
		double sum = 0;
		int* set = new int[node_num];
		line* lines = new line[line_num*2];
		for (int i = 0;i < node_num;i++) { set[i] = i; }
		int num1 = 0;
		for (int i = 0;i < node_num;i++)
		{
			Adlist_Node* temp = data[i].HEAD;
			while (temp->next != nullptr)
			{
				temp = temp->next;
				lines[num1].i = i;
				lines[num1].j = (int)temp->node - caps;
				lines[num1].weight = temp->weight;
				num1++;
			}
		}
		sort(lines, &lines[0] + line_num*2, cmp);
		for (int i = 0;i < node_num-1;i++)
		{
			int num = i;
			while (find(set,lines[num].i) == find(set,lines[num].j)) num++;
			out.push_back('<');
			if (caps == 65) { out.push_back('A' + lines[num].i); out.push_back('A' + lines[num].j); }
			else { out.push_back('a' + lines[num].i);out.push_back('a' + lines[num].j); }
			out.push_back('>');
			sum += lines[num].weight;
			set[lines[num].j] = lines[num].i;
		}
		return sum;
	}
	int find(int *set,int a)
	{
		if (set[a] == a) return a;
		else
		{
			return  find(set, set[a]);
		}
	}
	double Dijkstra(string& out ,int index)
	{

	};
	void Floyd()
	{
		double** temp = new double* [node_num];
		for (int i = 0;i < node_num;i++)
		{
			temp[i] = new double[node_num];
		}
		for (int i = 0;i < node_num;i++)
		{
			for (int j = 0;j < node_num;j++) temp[i][j] = data[i][j];
		}
		for (int k = 1;k < node_num;k++)
		{
			for (int i = 0;i < node_num;i++)
			{
				for (int j = 0;j < node_num;j++)
				{
					if (temp[i][j] == -1)
					{
						if (temp[i][k] != -1 && temp[k][j] != -1)
						{
							temp[i][j] = temp[i][k] + temp[k][j];
						}
					}
					else if (temp[i][j] > temp[i][k] + temp[k][j])
					{
						if (temp[i][k] != -1 && temp[k][j] != -1)
						{
							temp[i][j] = temp[i][k] + temp[k][j];
						}
					}
				}
			}
		}
		char a = 'A';
		if (cap_flag == 1) a = 'a';
		cout << "    ";
		for (int i = 0;i < node_num;i++)
		{
			cout << (char)(a + (int)i) << "   ";
		}
		cout << endl;
		for (int i = 0;i < node_num;i++)
		{
			cout << (char)(a + (int)i) << "   ";
			for (int j = 0;j < node_num;j++)
			{
				cout << temp[i][j] << "  ";
			}
			cout << endl;
		}
	};
private:
	Adlist_String* data;
	int caps;
	int node_num;
	int line_num;
	bool is_ori;
};
//3
struct Orlist_Node;
typedef struct Orlist_Head
{
	char node;
	Orlist_Node* out;//�Դ�nodeΪ�ߵ�ͷ
	Orlist_Node* in;//�Դ�nodeΪ�ߵ�β
	int weight;
	Orlist_Head() :node('\0'),out(nullptr),in(nullptr), weight(0) {};
}Orlist_Head;
typedef struct Orlist_Node :public Orlist_Head//��(headvex,tailvex)
{
	int headindex;
	int tailindex;
	Orlist_Node() :tailindex(-1),headindex(-1), Orlist_Head() {};
}Orlist_Node;
class OrList//ʮ������������
{
public:
	OrList() :heads(nullptr), node_num(0), line_num(0) {};
	~OrList() 
	{
		for (int i = 0;i < node_num;i++)
		{
			Clear(heads[i].out);
		}
		delete[] heads;
	};
	void Clear(Orlist_Node* head)
	{
		if (head == nullptr);
		else
		{
			Clear(head->out);
			delete head;
		}
	};
	int Set_OrList()
	{
		int n = 0, m = 0;
		char a = '\0', b = '\0';
		int flag = 65;//Ĭ�ϴ�д
		cout << "����ڵ����" << endl;
		cin >> n;
		node_num = n;
		heads = new Orlist_Head[n];
		for (int i = 0;i < n;i++)
		{
			heads[i].node = 'A' + i;
		}
		cout << "����߸���" << endl;
		cin >> m;
		line_num = m;
		cout << "����� �磨AB��" << endl;
		for (int i = 0;i < m;i++)
		{
			cin >> a >> b;
			if (a >= 'a' &&i==0)
			{
				flag = 97;
				for (int j = 0;j< n;j++)
				{
					heads[j].node = 'a' + j;
				}
			}
			Orlist_Node* out = new Orlist_Node();
			out->node = b;/*MAY HAVE QUESTION*/
			Orlist_Node* temp1 = heads[(int)a - flag].out;
			Orlist_Node* temp2 = heads[(int)b - flag].in;
			if (temp1 == nullptr)
			{
				Orlist_Node*& temp4 = heads[(int)a - flag].out;
				temp4 = out;
				temp4->headindex=(int)a - flag;
				temp4->tailindex = (int)b - flag;
				if (temp2 == nullptr)
				{
					Orlist_Node*& temp3 = heads[(int)b - flag].in;
					temp3 = out;
				}
				else
				{
					while (temp2->in != nullptr) temp2 = temp2->in;
					Orlist_Node*& temp3 = temp2;
					temp3->in = out;
				}
			}
			else
			{
				while (temp1->out != nullptr) temp1 = temp1->out;
				Orlist_Node*& temp4 = temp1;
				temp4->out = out;
				temp4->headindex = (int)a - flag;
				temp4->tailindex = (int)b - flag;
				if (temp2 == nullptr)
				{
					Orlist_Node*& temp3 = heads[(int)b - flag].in;
					temp3 = out;
				}
				else
				{
					while (temp2->in != nullptr) temp2 = temp2->in;
					Orlist_Node*& temp3 = temp2;
					temp3->in = out;
				}
			}
		}
		return 0;
	};
	int Paint()
	{
		for (int i = 0;i < node_num;i++)
		{
			Paint_Line(i);
		}
		return 0;
	}
	int Paint_Line(int i)
	{
		Orlist_Node* temp = heads[i].out;
		cout << heads[i].node << " -> ";
		while (temp != nullptr)
		{
			cout << temp->node << " -> ";
			temp = temp->out;
		}
		cout << "#" << endl;
		return 0;
	}
private:
	Orlist_Head* heads;
	int node_num;
	int line_num;
};
//4
struct Mulist_Node;
typedef struct Mulist_Head
{
	char node;
	Mulist_Node* left;
	Mulist_Head() :node('\0'), left(nullptr) {};
}Mulist_Head;
typedef struct Mulist_Node:public Mulist_Head
{
	int trans;
	int leftindex;
	int rightindex;
	Mulist_Node* right;
	Mulist_Node() :Mulist_Head(), leftindex(-1), rightindex(-1), right(nullptr),trans(0) {};
}Mulist_Node;
class MuList//����
{
public:
	MuList() :heads(nullptr),node_num(0),line_num(-1){};
	~MuList() {};
	int Set_Mulist()
	{
		int n = 0, m = 0;
		char a = '\0', b = '\0';
		int flag = 65;//Ĭ�ϴ�д
		cout << "����ڵ����" << endl;
		cin >> n;
		node_num = n;
		heads = new Mulist_Head[n];
		for (int i = 0;i < n;i++)
		{
			heads[i].node = 'A' + i;
		}
		cout << "����߸���" << endl;
		cin >> m;
		line_num = m;
		cout << "����� �磨AB��" << endl;
		for (int i = 0;i < m;i++)
		{
			cin >> a >> b;
			if (a >= 'a' && i == 0)
			{
				for (int j = 0;j < n;j++)
				{
					flag = 97;
					heads[j].node = 'a' + j;
				}
			}
			Mulist_Node* temp1 = new Mulist_Node();
			temp1->node = b;
			temp1->leftindex = (int)a - flag;
			temp1->rightindex = (int)b - flag;
			if (heads[(int)b - flag].left == nullptr)
			{
				heads[(int)b - flag].left = temp1;
			}
			else
			{
				Mulist_Node* temp2 = heads[(int)b - flag].left;
				Mulist_Node* temp4 = heads[(int)b - flag].left;
				while (temp2 == nullptr)
				{
					temp4 = temp2;
					if (temp2->leftindex == (int)b - flag) temp2 = temp2->left;
					else if (temp2->rightindex == (int)b - flag) temp2 = temp2->right;
				}
				Mulist_Node*& temp3 = temp4;
				if (temp3->leftindex == (int)b - flag) temp3->left=temp1;
				else if (temp3->rightindex == (int)b - flag) temp3->right=temp1;
			}
			if (heads[(int)a - flag].left == nullptr)
			{
				heads[(int)a - flag].left = temp1;
			}
			else
			{
				Mulist_Node* temp2 = heads[(int)a - flag].left;
				Mulist_Node* temp4 = heads[(int)a - flag].left;
				while (temp2 == nullptr)
				{
					temp4 = temp2;
					if (temp2->leftindex == (int)b - flag) temp2 = temp2->left;
					else if (temp2->rightindex == (int)b - flag) temp2 = temp2->right;
				}
				Mulist_Node*& temp3 = temp4;
				if (temp3->leftindex == (int)b - flag) temp3->left = temp1;
				else if (temp3->rightindex == (int)b - flag) temp3->right = temp1;
			}
		}
		return 0;
	}
	void Print()
	{
		for (int i = 0;i < node_num;i++)
		{
			Print_line(i);
		}
	};
	void Print_line(int i)
	{
		Mulist_Node* temp= heads[i].left;
		cout << heads[i].node << " <-> ";
		while (temp != nullptr)
		{
			cout << "|" << temp->leftindex<<","<<temp->rightindex << "| <-> ";
			if (temp->leftindex == i) temp = temp->left;
			else if (temp->rightindex == i)temp = temp->right;
		}
		cout << "#" << endl;
	};
	void Insert_Vex(Mulist_Head fresh)
	{
		node_num++;
		if (fresh.node == '\0') fresh.node = heads[node_num - 2].node + 1;
		Mulist_Head* new_heads = new Mulist_Head[node_num];
		for (int i = 0;i < node_num - 1;i++)
		{
			new_heads[i] = heads[i];
		}
		new_heads[node_num - 1] = fresh;
		delete[] heads;
		heads = new_heads;
	}
	void Insert_Arc(Mulist_Head a, Mulist_Head b)
	{
		int index_a = 0, index_b = 0;
		Mulist_Node* fresh = new Mulist_Node();
		for (int i = 0;i < node_num;i++)
		{
			if (heads[i].node == a.node)index_a = i;
			if(heads[i].node == b.node)index_b = i;
		}
		fresh->leftindex = index_a;
		fresh->rightindex = index_b;
		fresh->node = b.node;
		Mulist_Node* temp1 = heads[index_a].left;
		Mulist_Node* temp3 = heads[index_a].left;
		Mulist_Node* temp2 = heads[index_b].left;
		Mulist_Node* temp4 = heads[index_b].left;
		while (temp1 != nullptr)
		{
			temp3 = temp1;
			if (temp1->leftindex == index_a) temp1 = temp1->left;
			else if (temp1->rightindex == index_a) temp1 = temp1->right;
		}
		Mulist_Node*& temp5 = temp3;
		if (temp3->leftindex == index_a) temp5->left = fresh;
		else if (temp3->rightindex == index_a) temp5->right = fresh;
		while (temp2 != nullptr)
		{
			temp4 = temp2;
			if (temp2->leftindex == index_b) temp2 = temp2->left;
			else if (temp2->rightindex == index_b) temp2 = temp2->right;
		}
		Mulist_Node*& temp6 = temp4;
		if (temp4->leftindex == index_b) temp6->left = fresh;
		else if (temp4->rightindex == index_b) temp6->right = fresh;
	};
	void Insert_Arc(char a, char b)
	{
		int index_a = 0, index_b = 0;
		Mulist_Node* fresh = new Mulist_Node();
		for (int i = 0;i < node_num;i++)
		{
			if (heads[i].node == a)index_a = i;
			if (heads[i].node == b)index_b = i;
		}
		fresh->leftindex = index_a;
		fresh->rightindex = index_b;
		fresh->node = b;
		Mulist_Node* temp1 = heads[index_a].left;
		Mulist_Node* temp3 = heads[index_a].left;
		Mulist_Node* temp2 = heads[index_b].left;
		Mulist_Node* temp4 = heads[index_b].left;
		while (temp1 != nullptr)
		{
			temp3 = temp1;
			if (temp1->leftindex == index_a) temp1 = temp1->left;
			else if (temp1->rightindex == index_a) temp1 = temp1->right;
		}
		Mulist_Node*& temp5 = temp3;
		if (temp3->leftindex == index_a) temp5->left = fresh;
		else if (temp3->rightindex == index_a) temp5->right = fresh;
		while (temp2 != nullptr)
		{
			temp4 = temp2;
			if (temp2->leftindex == index_b) temp2 = temp2->left;
			else if (temp2->rightindex == index_b) temp2 = temp2->right;
		}
		Mulist_Node*& temp6 = temp4;
		if (temp4->leftindex == index_b) temp6->left = fresh;
		else if (temp4->rightindex == index_b) temp6->right = fresh;
	};
	void Delete_Vex(Mulist_Head a)
	{

	};
	void Delete_Vex(char a)//HAVE QUESTION
	{
		int index = 0;
		for (int i = 0;i < node_num;i++)
		{
			if (heads[i].node == a) index = i;
		}
		node_num--;
		Mulist_Node* temp1 = heads[index].left;
		Mulist_Node* temp2 = heads[index].left;
		Mulist_Node* temp3 = heads[index].left;//b
		Mulist_Node* temp4 = heads[index].left;//b
		/*while (temp2 != nullptr)
		{
			temp1->trans = 1;
			if (temp1->leftindex == index)
			{
				int temp_index = temp1->rightindex;
				temp2 = temp1->left;
				temp3 = heads[temp_index].left;
				while (temp3->trans != 1)
				{
					temp4 = temp3;
					if (temp3->leftindex == temp_index) temp3 = temp3->left;
					else if (temp3->rightindex == temp_index)temp3 = temp3->right;
				}
				int flag = 0;
				if (temp4->leftindex == temp_index) flag = 1;
				else if (temp4->rightindex == temp_index) flag = 2;
				Mulist_Node*& temp5 = temp4;
				if (flag==1)
				{
					if (temp3->leftindex == temp_index) temp5->left = temp3->left;
					if (temp3->rightindex == temp_index) temp5->left = temp3->right;
				}
				else if(flag==2)
				{
					if (temp3->leftindex == temp_index) temp5->right = temp3->left;
					if (temp3->rightindex == temp_index) temp5->right = temp3->right;
				}
			}
			else if (temp1->rightindex == index)
			{
				int temp_index = temp1->leftindex;
				temp2 = temp1->right;
				temp3 = heads[temp_index].left;
				while (temp3->trans != 1)
				{
					temp4 = temp3;
					if (temp3->leftindex == temp_index) temp3 = temp3->left;
					else if (temp3->rightindex == temp_index)temp3 = temp3->right;
				}
				int flag = 0;
				if (temp4->leftindex == temp_index) flag = 1;
				else if (temp4->rightindex == temp_index) flag = 2;
				Mulist_Node*& temp5 = temp4;
				if (flag == 1)
				{
					if (temp3->leftindex == temp_index) temp5->left = temp3->left;
					if (temp3->rightindex == temp_index) temp5->left = temp3->right;
				}
				else if (flag == 2)
				{
					if (temp3->leftindex == temp_index) temp5->right = temp3->left;
					if (temp3->rightindex == temp_index) temp5->right = temp3->right;
				}
			}
			if (temp1->leftindex == index) temp2 = temp1->left;
			else if (temp1->rightindex == index)temp2 = temp1->right;
			delete temp1;
			temp1 = temp2;
		}
		*/
		Mulist_Head* new_heads = new Mulist_Head[node_num];
		for (int i = 0;i < node_num;i++) 
		{
			for (int j = 0;j < node_num + 1;j++)
			{
				if (j != index) new_heads[i] = heads[j];
				else continue;
			}
		}
		delete[] heads;
		heads = new_heads;
	};
private:
	Mulist_Head* heads;
	int node_num;
	int line_num;
};
//1.1
void test_AdMatrix()
{
	AdMatrix matrix;
	matrix.Set_Matrix();
	matrix.Print_Matrix();
	string a,b,c,d,e;
	matrix.DFS(a,0);
	cout <<"DFS:" << a << endl;
	matrix.BFS(b, 0);
	cout <<"BFS:" << b<<endl;
	double prim_sum=matrix.Prim(c,0);
	if (prim_sum != -1)
	{
		cout << "Prim:" << c << " sum:" << prim_sum << endl;
		double kruskal_sum = matrix.Kruskal(d);
		cout << "Kruskal:" << d << " sum:" << kruskal_sum << endl;
		double dijkstra_sum = matrix.Dijkstra(e, 0);
		cout << "Dijkstra:" << e << " sum:" << dijkstra_sum << endl;
		cout << "Floyd:" << endl;
		matrix.Floyd();
	}
};
//2.1
void test_Adlist()
{
	AdList list;
	list.Set_AdList();
	list.Print_Adlist();
	string a,b,c,d;
	list.DFS(a, 0);
	cout << "DFS:" << a << endl;
	list.BFS(b, 0);
	cout << "BFS:" << b << endl;
	double prim_sum = list.Prim(c, 0);
	if (prim_sum != -1)
	{
		cout << "Prim:" << c << " sum:" << prim_sum << endl;
		double kruskal_sum = list.Kruskal(d);
		cout << "Kruskal:" << d << " sum:" << kruskal_sum << endl;
	}
};
//3.1
void test_OrList()
{
	OrList list;
	list.Set_OrList();
	list.Paint();
};
//4.1
void test_MuList()
{
	MuList list;
	list.Set_Mulist();
	//list.Print();
	Mulist_Head fresh;
	list.Insert_Vex(fresh);
	list.Print();
	list.Insert_Arc('d', 'c');
	list.Print();
	list.Delete_Vex('e');
	list.Print();
}
int main()
{
	//test_AdMatrix();
	test_Adlist();
	//test_OrList();
	//test_MuList();
}
//��������
/*���ڽӾ���
0
5
8
AC
CD
ED
DB
BD
DE
DC
CA
*/
/*���ڽӱ���
1
0
6
10
AB
6
AC
1
AD
5
BC
5
CD
5
BE
3
CE
6
CF
4
EF
6
DF
2
*/