#include <iostream>
#include <vector>
#include <queue>
using namespace std;

typedef struct BST_Node
{
	int data;
	int hi;
	BST_Node* left;
	BST_Node* right;
	BST_Node() :left(nullptr), right(nullptr), data(0), hi(0) {};
}BST_Node;

class BST
{
public:
	~BST()
	{
		queue<BST_Node*> q;
		q.push(root);
		while (!q.empty())
		{
			if (q.front()->left != nullptr)q.push(q.front()->left);
			if (q.front()->right != nullptr)q.push(q.front()->right);
			delete q.front();
			q.pop();
		}
	};
	void Insert_BST(int in, BST_Node*& node)//相等的数字在左子树
	{
		if (node == nullptr)
		{
			node_num++;
			node = new BST_Node;
			node->data = in;
		}
		else if (in <= node->data)
		{
			Insert_BST(in, node->left);
		}
		else
		{
			Insert_BST(in, node->right);
		}
	};
	void Set_BST()
	{
		int in;
		cout << "输入任意字母代表结束输入" << endl;
		while (cin >> in)
		{
			Insert_BST(in, root);
		}
	};
	void Delete_BST(int fresh, BST_Node*& node, BST_Node*& pre)
	{
		if (node == nullptr) cout << "该数不存在" << endl;
		else if (fresh == node->data)
		{
			node_num--;
			BST_Node* left = node->left;
			BST_Node* right = node->right;
			if (node == root)
			{
				if (left != nullptr)
				{
					root = left;
					while (left->right != nullptr) left = left->right;
					BST_Node*& temp = left;
					temp->right = right;
				}
				else
				{
					root = right;
				}
			}
			else
			{
				delete node;
				if (pre->left == node)
				{
					pre->left = left;
					if (right != nullptr) while (left->right != nullptr) left = left->right;
					BST_Node*& temp = left;
					if (left != nullptr)temp->right = right;
				}
				else if (pre->right == node)
				{
					pre->right = right;
					if (left != nullptr) while (left->left != nullptr) right = right->left;
					BST_Node*& temp = right;
					if (right != nullptr)temp->left = left;
				}
			}
		}
		else if (fresh < node->data) Delete_BST(fresh, node->left, node);
		else if (fresh > node->data) Delete_BST(fresh, node->right, node);
	};
	int Height(BST_Node* node, int add = 1)
	{
		int height = 0, left = 0, right = 0;
		node->hi = add;
		add++;
		if (node->left == nullptr && node->right == nullptr);
		else
		{
			if (node->left != nullptr)left = Height(node->left, add);
			if (node->right != nullptr)right = Height(node->right, add);
			height = (left > right ? left : right);
		}
		return height + 1;
	}
	double ASL_Success(BST_Node* node)
	{
		static double ans = 0;
		if (node == root) ans = 0;
		if (node == nullptr);
		else
		{
			ans += node->hi;
			ASL_Success(node->left);
			ASL_Success(node->right);
		}
		return ans / node_num;
	};
	double ASL_Fail(BST_Node* node)
	{
		static double ans = 0;
		if (node == root) ans = 0;
		if (node->left != nullptr) ASL_Fail(node->left);
		else ans += node->hi + 1;
		if (node->right != nullptr)ASL_Fail(node->right);
		else ans += node->hi + 1;
		return ans / node_num;
	};
	bool Find(int in, BST_Node* node)
	{
		if (node == nullptr) return false;
		else if (node->data == in) return true;
		else if (node->data > in) Find(in, node->left);
		else Find(in, node->right);
	};
	void In_Order(BST_Node* node, vector<int>& out)
	{
		if (node == nullptr);
		else
		{
			In_Order(node->left, out);
			out.push_back(node->data);
			In_Order(node->right, out);
		}
		return;
	};
	BST_Node* root = nullptr;
	int node_num = 0;
};

void test(BST& a)
{
	vector<int> b;
	a.Set_BST();
	a.In_Order(a.root, b);
	cout << "由小到大排序为： " << endl;
	for (int i = 0;i < b.size();i++) cout << b[i] << " ";
	cout << endl;
	cout << "树高为：" << a.Height(a.root) << endl;
	cout << "查找成功的ASL为： " << a.ASL_Success(a.root) << endl;
	cout << "查找失败的ASL为： " << a.ASL_Fail(a.root) << endl;
};

void test1(BST& a)
{
	bool running = true;
	cin.clear(); // 清除错误状态
	cin.ignore(numeric_limits<streamsize>::max(), '\n'); // 忽略错误输入
	int inn = 0;
	cout << "输入待查找的数 (输入任意字母代表结束输入)" << endl;
	while (cin >> inn)
	{
		if (a.Find(inn, a.root)) cout << "存在" << endl;
		else cout << "不存在" << endl;
	}
};

void test2(BST& a)
{
	bool running = true;
	cin.clear();
	cin.ignore(numeric_limits<streamsize>::max(), '\n');
	int inn = 0, in = 0;
	cout << "分别输入操作和待操作数 1为插入操作，2为删除操作(如：1 3 为插入3)" << endl;
	cout << "(输入任意字母代表结束输入)" << endl;
	while (cin >> in >> inn)
	{
		switch (in)
		{
		case 1:
			a.Insert_BST(inn, a.root);
			break;
		case 2:
			a.Delete_BST(inn, a.root, a.root);
			break;
		default:
			cout << "错误" << endl;
			break;
		}
	}
};

void test3(BST& a)
{
	vector<int> b;
	a.In_Order(a.root, b);
	cout << "由小到大排序为： " << endl;
	for (int i = 0;i < b.size();i++) cout << b[i] << " ";
	cout << endl;
	cout << "树高为：" << a.Height(a.root) << endl;
	cout << "查找成功的ASL为： " << a.ASL_Success(a.root) << endl;
	cout << "查找失败的ASL为： " << a.ASL_Fail(a.root) << endl;
}

int main()
{
	BST a;
	test(a);
	test1(a);
	test2(a);
	test3(a);
}